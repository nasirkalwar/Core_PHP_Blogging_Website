<?php
    require_once('header.php');
    require_once('sidebar.php');

    $query      = "SELECT * FROM user WHERE role_id=2 ORDER BY user_id DESC";
    $result     = execute_query($query);
    
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Users<a href="add_users.php" class="btn btn-warning p-3" style="float: right;">Add User</a></h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; padding: 10px; color:white; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Address</th>
                <th>Image</th>
                <th>Is_Approve</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Status Action</th>
            </tr>
        </thead>
        <tbody>

            <?php
                if($result->num_rows)
            {
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $row["first_name"]." ".$row["last_name"]; ?></td>
                <td><?php echo $row["email"]; ?></td>
                <td><?php echo $row["gender"]; ?></td>
                <td><?php echo $row["date_of_birth"]; ?></td>
                <td><?php echo $row["address"]; ?></td>
                <td><img src="../user/<?php echo $row["user_image"]; ?>" alt="image" width="50px" hieght="50px"></td>
                <td><?php echo $row["is_approved"]; ?></td>
                <td><?php echo $row["is_active"]; ?></td>
                <td><a href="add_users.php?user_id=<?php echo $row["user_id"]; ?>" class="btn btn-primary mr-1" >Edit</a></td>
                <td>
                    <?php 
                    if ($row["is_active"]=="Active") {
                    ?>
                    <a href="process.php?action=active_user&user_id=<?php echo $row["user_id"]; ?>" class="btn btn-danger mr-1">InActive</a>
                    <?php
                    }else{
                    ?>
                    <a href="process.php?action=inactive_user&user_id=<?php echo $row["user_id"]; ?>" class="btn btn-primary mr-1">Active</a>

                    <?php
                    }
                    ?>
                </td>
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
    </table>
    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>