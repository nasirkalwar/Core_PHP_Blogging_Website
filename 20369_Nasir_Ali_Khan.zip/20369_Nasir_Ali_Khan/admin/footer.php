  
    <!-- Datatable File Link-->
    <script type="text/javascript" src="js/jquery1.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js" ></script>
    <script type="text/javascript">

        $(document).ready( function () {
            $('#table_id').DataTable();
        } );
 
   </script>

    <!-- Bootstrap File Link-->
    <script src="../bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap Sidebar Links-->

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>