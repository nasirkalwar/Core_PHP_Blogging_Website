<?php
    require_once('header.php');
    require_once('sidebar.php');
    
    $connection = DB_connection("localhost", "root", "","20369_nasir_ali_khan");
    $query  = "SELECT * FROM user WHERE is_approved NOT LIKE 'Approved' ORDER BY user_id DESC";
    $result  = execute_query($query);
    
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>

<body onload="get_user_request()">

    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Users Request</h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; color:white; padding: 10px; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Role ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Address</th>
                <th>Image</th>
                <th>Is_Approve</th>
                <th>Approve Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                if($result->num_rows)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {
            ?>
            <tr>
                <td><?php echo $row["user_id"]; ?></td>
                <td><?php echo $row["role_id"]; ?></td>
                <td><?php echo $row["first_name"]; ?> <?php echo $row["last_name"]; ?></td>
                <td><?php echo $row["email"]; ?></td>
                <td><?php echo $row["gender"]; ?></td>
                <td><?php echo $row["date_of_birth"]; ?></td>
                <td><?php echo $row["address"]; ?></td>
                <td><?php echo $row["user_image"]; ?></td>
                <td><?php echo $row["is_approved"]; ?></td>
                <td>
                    <?php 
                    if ($row["is_approved"]=="Rejected") {
                    ?>
                        <p>Rejected</p>
                    <?php
                    }else{
                    ?>
                        <a href="process.php?action=approved_user&user_id=<?php echo $row["user_id"]; ?>" class="btn btn-primary mr-1">Approved</a>
                        <a href="process.php?action=rejected_user&user_id=<?php echo $row["user_id"]; ?>" class="btn btn-danger mr-1">Rejected</a>
                        <?php
                    }
                    ?>
                </td>
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
    </table>
    </div>

<?php
    DB_des_connection();
    require_once('footer.php');

?>