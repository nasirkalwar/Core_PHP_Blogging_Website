<?php
    require_once('header.php');
    require_once('sidebar.php');

    $query  = "SELECT * FROM user_feedback ORDER BY feedback_id DESC";
    $result  = execute_query($query);
    
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Feedbacks</h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; color:white; padding: 10px; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
        <table  id="table_id" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>User Email</th>
                    <th>Feedback</th>
                    <th>Create_at</th>
                </tr>
            </thead>
            <tbody>
            <?php
                if($result->num_rows)
            {
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $row["user_id"]; ?></td>
                <td><?php echo $row["user_name"]; ?></td>
                <td><?php echo $row["user_email"]; ?></td>
                <td><?php echo $row["feedback"]; ?></td>
                <td><?php echo $row["created_at"]; ?></td>                
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
        </table>
    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>