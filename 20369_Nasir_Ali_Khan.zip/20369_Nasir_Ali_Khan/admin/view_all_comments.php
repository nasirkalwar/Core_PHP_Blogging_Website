<?php
    require_once('header.php');
    require_once('sidebar.php');

    $query  = "SELECT * FROM post_comment ORDER BY post_comment_id DESC";
    $result  = execute_query($query);
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Comments</h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; color:white; padding: 10px; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Post ID</th>
                <th>User ID</th>
                <th>Comment</th>
                <th>Created_at</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                if($result->num_rows)
            {
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $row["post_id"]; ?></td>
                <td><?php echo $row["user_id"]; ?></td>
                <td><?php echo $row["comment"]; ?></td>
                <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["comment_active"]; ?></td>
                <td>
                    <?php 
                    if ($row["comment_active"]=="Active") {
                    ?>
                    <a href="process.php?action=active_comment&comment_id=<?php echo $row["post_comment_id"]; ?>" class="btn btn-danger mr-1">InActive</a>
                    <?php
                    }else{
                    ?>
                    <a href="process.php?action=inactive_comment&comment_id=<?php echo $row["post_comment_id"]; ?>" class="btn btn-primary mr-1">Active</a>

                    <?php
                    }
                    ?>
                </td>
                
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
    </table>
    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>