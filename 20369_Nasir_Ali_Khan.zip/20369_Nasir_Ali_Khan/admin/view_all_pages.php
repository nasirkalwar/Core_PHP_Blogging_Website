<?php
    require_once('header.php');
    require_once('sidebar.php');

    $user_id    = $_SESSION["user"]["user_id"];
    $query = "SELECT * FROM blog WHERE user_id = $user_id ORDER BY blog_id DESC";

    $result     = execute_query($query);
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Pages<a href="add_blog_page.php" class="btn btn-warning p-3" style="float: right;">Add Blog Page</a></h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; color:white; padding: 10px; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Blog ID</th>
                <th>Blog Title</th>
                <th>Image</th>
                <th>Post Per Page</th>
                <th>Created_at</th>
                <th>Status</th>
                <td>Edit</td>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                if($result->num_rows)
            {
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $row["blog_id"]; ?></td>
                <td><?php echo $row["blog_title"]; ?></td>
                <td><img src="<?php echo $row["blog_background_image"]; ?>" alt="image" width="50px" hieght="50px"></td>
                <td><?php echo $row["post_per_page"]; ?></td>
                <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["blog_status"]; ?></td>
                <td><a href="add_blog_page.php?blog_id=<?php echo $row["blog_id"]; ?>" class="btn btn-primary mr-1">Edit</a></td>
                <td>
                    <?php 
                    if ($row["blog_status"]=="Active") {
                    ?>
                    <a href="process.php?action=active_page&blog_id=<?php echo $row["blog_id"]; ?>" class="btn btn-danger mr-1">InActive</a>
                    <?php
                    }else{
                    ?>
                    <a href="process.php?action=inactive_page&blog_id=<?php echo $row["blog_id"]; ?>" class="btn btn-primary mr-1">Active</a>

                    <?php
                    }
                    ?>
                </td>
                
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
    </table>
    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>