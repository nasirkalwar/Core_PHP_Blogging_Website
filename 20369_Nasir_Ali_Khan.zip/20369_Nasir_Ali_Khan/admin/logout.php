<?php
	require_once("../require/session.php");

	destroy_session();	

?>