<?php
    require_once('header.php');
    require_once('sidebar.php');

    $query  = "SELECT * FROM blog";
    $result  = execute_query($query);
    
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
        
          <div class="row">
            <div class="col-md-2"></div>
              <div class="col-md-8 rounded text-white" style="background-color: darkseagreen;">

              <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Add User<a href="view_all_users.php" class="btn btn-warning p-3" style="float: right;">View Users</a></h1>
                <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; color:white; padding: 10px; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
                ?>
                              <div id="check"></div>
                <form action="process.php" method="POST">
                  
                  <select class="form-select" aria-label="Default select example" name="user_role" required>
                    <option selected align="center">--- Select User Role ---</option>
                    <option value="1">Admin</option>
                    <option value="2">User</option>
                  </select>
                            <div class="row mt-3">
                            <div class="col">
                              <label for="exampleFormControlInput1" class="form-label">First Name</label>
                              <input type="text" name="first_name" class="form-control" placeholder="First name" aria-label="First name" required>
                            </div>
                            <div class="col">
                              <label for="exampleFormControlInput1" class="form-label">Last Name</label>
                              <input type="text" name="last_name" class="form-control" placeholder="Last name" aria-label="Last name" required>
                            </div>
                          </div>

                          <div class="row mt-3">
                            <div class="col">
                            <div class="mb-3">

                              <label for="exampleFormControlInput1" class="form-label">Email Address</label>
                              <input type="email" name="email" class="form-control" id="email" onkeyup="checkemail(this.value)" id="exampleFormControlInput1" placeholder="name@example.com" required>
                            </div>
                            </div>
                            <div class="col">
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Password</label>
                              <input type="password" name="password"class="form-control" id="exampleFormControlInput1" placeholder="Enter Password" required>
                            </div>
                            </div>
                          </div>

                          <div class="row mt-3">
                            <div class="col">
                            <div class="mb-3">
                              <label for="formFile" class="form-label">Choice Image</label>
                              <input class="form-control" type="file" name="user_image" id="formFile" required>
                            </div>
                            </div>
                            <div class="col">
                            <div class="mb-3">
                              <label for="exampleFormControlInput1" class="form-label">Date of Birth</label>
                              <input type="text" name="dob" class="form-control" id="exampleFormControlInput1" placeholder="Enter your Date of Birth 2024/05/23" required>
                            </div>
                          </div>

                          <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                            <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Your Address" required></textarea>
                          </div>
                          <fieldset class="row mb-3">
                            <legend class="col-form-label col-sm-2 pt-0"><b>Gender :</b></legend>
                            <div class="col-sm-10">
                              <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="male" id="gridRadios1" value="option1" checked>
                                <label class="form-check-label" for="gridRadios1">
                                  Male
                                </label>
                              </div>
                              <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="female" id="gridRadios2" value="option2">
                                <label class="form-check-label" for="gridRadios2">
                                  Female
                                </label>
                              </div>
                            </div>
                          </fieldset>

                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="action" value="register" class="btn btn-primary m-3">Register</button>
                              </div>
                            </div>
                  
                </form>
            </div>
            <div class="col-md-2"></div>

    </div>


     <script type="text/javascript">
        function checkemail(email) {
            var ajax_request = null;

            if (window.XMLHttpRequest) {
                ajax_request = new XMLHttpRequest();
            } else {
                ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
            }

            ajax_request.onreadystatechange = function() {
                if (ajax_request.readyState == 4 && ajax_request.status == 200) {
                    document.getElementById("check").innerHTML = ajax_request.responseText;
                }
            };

            ajax_request.open("GET", "process.php?action=check_email&check_email=" + encodeURIComponent(email), true);
            ajax_request.send();
        }
    </script>
<?php
    DB_des_connection();
    require_once('footer.php');

?>		



