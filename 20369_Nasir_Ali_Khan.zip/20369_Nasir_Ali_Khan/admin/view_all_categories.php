<?php
    require_once('header.php');
    require_once('sidebar.php');

    $query  = "SELECT * FROM category";
    $result  = execute_query($query);
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
    <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;">Manage Categories 
        <a href="add_category.php" class="btn btn-warning p-3" style="float: right;">Add Category</a></h1>
            <?php 
                    if(isset($_REQUEST["message"]))
                        {
                        ?>
                            <p style="background-color: <?php echo $_REQUEST["color"]; ?>; padding: 10px; color:white; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                        <?php
                        }
            ?>
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Category Name</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created_at</th>
                <td>Edit</td>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
                        <?php
                if($result->num_rows)
            {
                while($row = mysqli_fetch_assoc($result))
                {
            ?>
            <tr>
                <td><?php echo $row["category_title"]; ?></td>
                <td><?php echo $row["category_description"]; ?></td>
                <td><?php echo $row["category_status"]; ?></td>
                <td><?php echo $row["created_at"]; ?></td>
                <td><a href="add_category.php?category_id=<?php echo $row["category_id"]; ?>" class="btn btn-primary mr-1" >Edit</a></td>
                <td>
                    <?php 
                    if ($row["category_status"]=="Active") {
                    ?>
                    <a href="process.php?action=active_category&category_id=<?php echo $row["category_id"]; ?>" class="btn btn-danger mr-1">InActive</a>
                    <?php
                    }else{
                    ?>
                    <a href="process.php?action=inactive_category&category_id=<?php echo $row["category_id"]; ?>" class="btn btn-success mr-1">Active</a>

                    <?php
                    }
                    ?>
                </td>
            </tr>
            <?php
                }
            }
            ?>
        </body>
        <tfoot>
            <tr>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
                <th>-----</th>
            </tr>
        </tfoot>
    </table>
    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>