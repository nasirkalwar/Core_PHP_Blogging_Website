 <?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
mysqli_report(false);
require_once("../require/functions.php");
require_once("../require/database.php");
    

//Add Blog Page

if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "add_blog") {

        $tmp_name       = $_FILES["blog_image"]["tmp_name"];
        $orignal_name   = $_FILES["blog_image"]["name"];
        $file_name      = time() . "_" . $orignal_name;
        $path           = "blog_page_images/".$file_name;
    
        move_uploaded_file($tmp_name,$path);

    $query  = "INSERT INTO blog (user_id, blog_title, post_per_page, blog_background_image, blog_status) VALUES ('".$_POST["user_id"]."', '".$_POST["blog_title"]."', '".$_POST["post_per_page"]."', '".$path."', '".$_POST["blog_status"]."')";
    $result =   execute_query($query);
    
    if ($result) {
    
        header("location: add_blog_page.php?message=New Blog Page Inserted successfully....!&color=green");
    } else {
        header("location: add_blog_page.php?message=New Blog Page Not Inserted Try Again Latter....!&color=lightpink");
    }
}

//Update Blog Page

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "update_blog") {


        $tmp_name       = $_FILES["blog_image"]["tmp_name"];
        $orignal_name   = $_FILES["blog_image"]["name"];
        $file_name      = time() . "_" . $orignal_name;
        $path           = "post_images/".$file_name;
        $blog_id        = $_POST["blog_id"];
        $time           = date('Y-m-d H:i:s');

        move_uploaded_file($tmp_name,$path);

    $query  = "UPDATE blog SET blog_title='".$_POST["blog_title"]."', post_per_page='".$_POST["post_per_page"]."', blog_background_image='".$path."', user_id='".$_POST["user_id"]."', blog_status='".$_POST["blog_status"]."', updated_at='".$time."' WHERE blog_id= $blog_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_pages.php?message=Blog Page Update successfully.....!&color=green");
    } else {
        header("location: view_all_pages.php?message=Blog Page Not Update Try Again Latter.....!&color=lightpink");
    }
}

//Active Blog Page

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "inactive_page") {

    $blog_id         = $_GET["blog_id"];

    $query  = "UPDATE blog SET blog_status='Active' WHERE blog_id= $blog_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_pages.php?message=Blog Page Active successfully.....!&color=green");
    } else {
        header("location: view_all_pages.php?message=Blog Page Not Active Try Again Latter.....!&color=lightpink");
    }
}

//InActive Blog Page


else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "active_page") {

    $blog_id         = $_GET["blog_id"];

    $query  = "UPDATE blog SET blog_status='InActive' WHERE blog_id= $blog_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_pages.php?message=Blog Page InActive successfully.....!&color=green");
    } else {
        header("location: view_all_pages.php?message=Blog Page Not InActive Try Again Latter.....!&color=lightpink");
    }
}

//Add Category

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "add_category") {

    $title			  = $_POST["category_title"];
    $description 	  = $_POST["category_description"];
    $category_status  = $_POST["category_status"];

    $query 	= "INSERT INTO category (category_title, category_description,category_status) VALUES ('$title', '$description','$category_status')";
	$result	=	mysqli_query($connection, $query);
    
    if ($result) {
	
		header("location: add_category.php?message=New Category Inserted successfully...!&color=green");
    } else {
		header("location: add_category.php?message=New Category Not Inserted Try Again Latter....!&color=lightpink");
    }
}

//Update Category

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "update_category") {

    $title			= $_POST["category_title"];
    $description 	= $_POST["category_description"];
	$cat_id			= $_POST["category_id"];
    $time           = date('Y-m-d H:i:s');
    $status         = $_POST["category_status"];

    $query 	= "UPDATE category SET category_title='".$title."', category_description='".$description."', updated_at='".$time."', category_status='".$status."' WHERE category_id= $cat_id";
	$result	=	execute_query($query);
    if ($result) {
	
		header("location: view_all_categories.php?message=Category Update successfully.....!&color=green");
    } else {
		header("location: view_all_categories.php?message=New Category Not Update Try Again Latter.....!&color=lightpink");
    }
}

//Active Category

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "inactive_category") {

    $category_id = $_GET["category_id"];

    $query  = "UPDATE category SET category_status='Active' WHERE category_id= $category_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_categories.php?message=Category Active successfully.....!&color=green");
    } else {
        header("location: view_all_categories.php?message=Category Not Active Try Again Latter.....!&color=lightpink");
    }
}

//InActive Category


else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "active_category") {

    $category_id = $_GET["category_id"];

    $query  = "UPDATE category SET category_status='InActive' WHERE category_id= $category_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_categories.php?message=Category InActive successfully.....!&color=green");
    } else {
        header("location: view_all_categories.php?message=Category Not InActive Try Again Latter.....!&color=lightpink");
    }
}

//Attachment loop

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "attachment") {

    $count = $_GET["count"];
    for($a=1; $a <= $count; $a++){
        ?>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="formFile" class="form-label">Attachment Title</label>
                    <input class="form-control" type="text" name="attachment_title[]" placeholder="Enter Attachment Title" id="formFile">
                </div>                          
            </div>
             <div class="col-md-6">
                <div class="mb-3">
                    <label for="formFile" class="form-label">Attachment Image</label>
                    <input class="form-control" type="file" name="attachment_image[]" id="formFile">
                </div>
            </div>
        </div>
        <?php
        }                                 
}
//Add Post

if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "add_post") {

        $tmp_name       = $_FILES["featured_image"]["tmp_name"];
        $orignal_name   = $_FILES["featured_image"]["name"];
        $file_name      = time() . "_" . $orignal_name;
        $path           = "post_images/".$file_name;

        move_uploaded_file($tmp_name,$path);


    $query  = "INSERT INTO post (blog_id, post_title, post_summary, post_description, featured_image, is_comment_allowed) VALUES ('".$_POST["blog_id"]."', '".$_POST["post_title"]."', '".$_POST["post_summary"]."', '".$_POST["post_description"]."', '".$path."', '".$_POST["is_comment_allow"]."')";
    $result =   execute_query($query);

    if ($result) {
            extract($_POST);
            $post_id = mysqli_insert_id($connection);
            
            foreach ($category_id as $key => $value) {
            $category_id    = $value;

                $query  = "INSERT INTO post_category (post_id, category_id) VALUES ('".$post_id."','".$category_id."')";
                $flag   = mysqli_query($connection,$query);
            }
             if($flag){
                    foreach ($_FILES['attachment_image']["name"] as $key => $value) {
                    $tmp_name           = $_FILES["attachment_image"]["tmp_name"][$key];
                    $orignal_name       = $_FILES["attachment_image"]["name"][$key];
                    $file_name          = time()."_".$_FILES["attachment_image"]["name"][$key];
                    $path               = "post_attachments/".$file_name;
                    $attachment_title   = $_POST["attachment_title"][$key];
                    // $id                 = mysqli_insert_id($connection);
                   if (move_uploaded_file($tmp_name, $path)){
                     $que  = "INSERT INTO post_atachment (post_id, post_attachment_title, post_attachment_path) VALUES ('".$post_id."','".$attachment_title."','".$path."')";
                        $flag_1   = mysqli_query($connection,$que);
                    }
                } 
                    if($flag_1){

                        $follow_query ="SELECT * FROM USER, blog, following_blog WHERE user.user_id = following_blog.follower_id AND blog.blog_id = following_blog.blog_following_id AND blog_id =".$_POST["blog_id"];
                        $follow_result   = mysqli_query($connection,$follow_query);

                            while($follow_user=mysqli_fetch_assoc($follow_result)){

                                require '../PHPMailer-master/src/PHPMailer.php';
                                require '../PHPMailer-master/src/SMTP.php';
                                require '../PHPMailer-master/src/Exception.php';

                                $mail = new PHPMailer();
                                $mail->isSMTP();
                                $mail->Host = 'smtp.gmail.com';
                                $mail->Port = 587;
                                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                                $mail->SMTPAuth = true;
                                $mail->Username = 'nalikkhan048@gmail.com'; 
                                $mail->Password = 'vedkydykylteoeqw'; 
                                $to = $follow_user["email"];
                                if (isset($to) && !empty($to)) {

                                $mail->setFrom("nalikkhan048@gmail.com", "Admin");
                                $mail->addAddress($to);

                                $mail->isHTML(true);
                                $mail->Subject  = "Post Update";
                                $mail->Body     = "New Post Upload On Your Follow Page....!";
                                $mail->send();

                                    if ($mail->send()) {
                                                    header("location: add_post.php?message=New Post Inserted successfully....!&color=green");

                                    } else {

                                        header("location:add_post.php?message=Mailer Error: $mail->ErrorInfo&color=red");

                                    }
                                }else {

                                    header("location:add_post.php?message=Recipient email address is required&color=red");

                                }

                        }
                        header("location: add_post.php?message=New Post Inserted successfully....!&color=green");
                    }
                }
    }else {
        header("location: add_post.php?message=New Post Not Inserted Try Again Latter....!&color=lightpink");
    }
}

//Update Post

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "update_post") {

        $tmp_name       = $_FILES["featured_image"]["tmp_name"];
        $orignal_name   = $_FILES["featured_image"]["name"];
        $file_name      = time() . "_" . $orignal_name;
        $path           = "post_images/".$file_name;
        $post_id         = $_POST["post_id"];
        $time           = date('Y-m-d H:i:s');
        move_uploaded_file($tmp_name,$path);


    $query  = "UPDATE post SET blog_id='".$_POST["blog_id"]."', post_title='".$_POST["post_title"]."', post_summary='".$_POST["post_summary"]."', post_description='".$_POST["post_description"]."', featured_image='".$path."', is_comment_allowed='".$_POST["is_comment_allow"]."', updated_at='".$time."' WHERE post_id= $post_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_posts.php?message=Post Update successfully.....!&color=green");
    } else {
        header("location: view_all_posts.php?message=Post Not Update Try Again Latter.....!&color=lightpink");
    }
}

//Active Post

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "inactive_post") {

    $post_id         = $_GET["post_id"];

    $query  = "UPDATE post SET post_status='Active' WHERE post_id= $post_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_posts.php?message=Post Active successfully.....!&color=green");
    } else {
        header("location: view_all_posts.php?message=Post Not Active Try Again Latter.....!&color=lightpink");
    }
}

//InActive Post


else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "active_post") {

    $post_id         = $_GET["post_id"];

    $query  = "UPDATE post SET post_status='InActive' WHERE post_id= $post_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_posts.php?message=Post InActive successfully.....!&color=green");
    } else {
        header("location: view_all_posts.php?message=Post Not InActive Try Again Latter.....!&color=lightpink");
    }
}

//Check Email Exist

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "check_email") {
    
    $email = $_GET["check_email"];
    
    $query = "SELECT * FROM user WHERE email = '$email'";          
    $result = execute_query($query);

     if ($result && mysqli_num_rows($result) > 0) {
        echo "<p style='background-color:red; text-align:center; border-radius:10px; padding:10px;'>This Email Already Registered. Use another Email for Registration...!</p>";
    } else {
        echo "<p>Email is available.</p>";
    }
}


//Add User

else if(isset($_POST["action"]) && $_POST["action"]=="register")
    {
        $tmp_name       = $_FILES["user_image"]["tmp_name"];
        $orignal_name   = $_FILES["user_image"]["name"];
        $file_name      = time() . "_" . $orignal_name;
        $path           = "multiple_images/".$file_name;
    
        move_uploaded_file($tmp_name,$path);
        
        $query = "INSERT INTO user (role_id, first_name, last_name, email, password, gender, date_of_birth, user_image, address) VALUES('".$_POST["user_role"]."','".$_POST["first_name"]."','".$_POST["last_name"]."','".$_POST["email"]."','".sha1($_POST["password"])."','".$_POST["gender"]."','".$_POST["dob"]."','".$path."','".$_POST["address"]."')";

        $result = execute_query($query); 
        if($result)
        {
            header("location: add_users.php?message=New User Add Successfully ...!&color=lightgreen");
        }
        else
        {
            header("location: add_users.php?message=New User Not Add Successfully Please Try Again Latter...!&color=lightred");
        }
    }


//Active User

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "inactive_user") {

    $user_id         = $_GET["user_id"];

    $query  = "UPDATE user SET is_active='Active' WHERE user_id= $user_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_users.php?message=user Active successfully.....!&color=green");
    } else {
        header("location: view_all_users.php?message=user Not Active Try Again Latter.....!&color=lightpink");
    }
}

//InActive User


else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "active_user") {

    $user_id         = $_GET["user_id"];

    $query  = "UPDATE user SET is_active='InActive' WHERE user_id= $user_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_users.php?message=User InActive successfully.....!&color=green");
    } else {
        header("location: view_all_users.php?message=user Not InActive Try Again Latter.....!&color=lightpink");
    }
}

//User Approved

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "approved_user") {

    $user_id         = $_GET["user_id"];

    $query  = "UPDATE user SET is_approved='Approved', is_active='Active' WHERE user_id= $user_id";
    $result =   execute_query($query);
    if ($result) {
            $que = "SELECT * FROM user WHERE user_id = $user_id";          
            $res = execute_query($que);
            $row = mysqli_fetch_assoc($res);
            email_send("nalikkhan048@gmail.com","Admin",$row["email"],"Account Request Email","Your Account Registeration Request Approved....!");
            header("location: user_request.php?message=user Approved Successfully.....!&color=green");
    } else {
        header("location: user_request.php?message=user Not Approved Try Again Latter.....!&color=lightpink");
    }
}

//User Rejected

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "rejected_user") {

    $user_id         = $_GET["user_id"];

    $query  = "UPDATE user SET is_approved='Rejected', is_active='InActive' WHERE user_id= $user_id";
    $result =   execute_query($query);
    if ($result) {

            $que = "SELECT * FROM user WHERE user_id = $user_id";          
            $res = execute_query($que);
            $row = mysqli_fetch_assoc($res);
            email_send("nalikkhan048@gmail.com","Admin",$row["email"],"Account Request Email","Your Account Registeration Request Rejected....!");
            header("location: user_request.php?message=User Rejected Successfully.....!&color=green");
    } else {
        header("location: user_request.php?message=user Not Rejected Try Again Latter.....!&color=lightpink");
    }
}

//Active Comment

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "inactive_comment") {

    $comment_id  = $_GET["comment_id"];

    $query  = "UPDATE post_comment SET comment_active='Active' WHERE post_comment_id= $comment_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_comments.php?message=Comment Active Successfully.....!&color=green");
    } else {
        header("location: view_all_comments.php?message=Comment Not Active Try Again Latter.....!&color=lightpink");
    }
}

//InActive Comment

else if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "active_comment") {

    $comment_id         = $_GET["comment_id"];

    $query  = "UPDATE post_comment SET comment_active='InActive' WHERE post_comment_id= $comment_id";
    $result =   execute_query($query);
    if ($result) {
    
        header("location: view_all_comments.php?message=Comment InActive Successfully.....!&color=green");
    } else {
        header("location: view_all_comments.php?message=Comment Not InActive Try Again Latter.....!&color=lightpink");
    }
}

?>

    