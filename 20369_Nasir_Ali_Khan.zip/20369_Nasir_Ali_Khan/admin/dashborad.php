<?php

    require_once('header.php');
    require_once('sidebar.php');


    //Count Total User 
    $query = "SELECT COUNT(*) AS user_count FROM user";
    $result   = execute_query($query);
    $user = mysqli_fetch_assoc($result);

    //Count Total User Requests 
    $query1     = "SELECT COUNT(*) AS user_request FROM user WHERE is_approved='pending'";
    $result1    = execute_query($query1);
    $user_req   = mysqli_fetch_assoc($result1);

    //Count Total User Approved 
    $query6     = "SELECT COUNT(*) AS user_approved FROM user WHERE is_approved='Approved'";
    $result6    = execute_query($query6);
    $user_appr  = mysqli_fetch_assoc($result6);

    //Count Total Blogs 
    $query2     = "SELECT COUNT(*) AS blog FROM blog";
    $result2    = execute_query($query2);
    $blog       = mysqli_fetch_assoc($result2);

    //Count Total Categories 
    $query3     = "SELECT COUNT(*) AS category FROM category";
    $result3    = execute_query($query3);
    $category   = mysqli_fetch_assoc($result3);

    //Count Total Comments 
    $query4     = "SELECT COUNT(*) AS comment FROM post_comment";
    $result4    = execute_query($query4);
    $comment    = mysqli_fetch_assoc($result4);

    //Count Total Feedbacks 
    $query5     = "SELECT COUNT(*) AS feedback FROM user_feedback";
    $result5    = execute_query($query5);
    $feedback   = mysqli_fetch_assoc($result5);

    //Count Total Posts 
    $post_query     = "SELECT COUNT(*) AS post_total FROM post";
    $post_result    = execute_query($post_query);
    $post_count     = mysqli_fetch_assoc($post_result);

    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    <div id="content" class="p-4 p-md-5 pt-5">
        <div class="row">
          <div class="card text-bg-primary text-white mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">Users</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="view_all_users.php" class="btn btn-primary p-2" style="float: right;">View Users</a>
                <?php echo $user["user_count"]; ?>
              </p>
            </div>
          </div>

          <div class="card text-bg-success mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">User Requests</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="user_request.php" class="btn btn-primary p-2" style="float: right;">View User Request</a>
                <?php echo $user_req["user_request"]; ?>
              </p>
            </div>
          </div>


          <div class="card text-bg-secondary mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">Approved User</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="user_request.php" class="btn btn-primary p-2" style="float: right;">View Users</a><?php echo $user_appr["user_approved"]; ?>
              </p>
            </div>
          </div>
          <div class="card mb-3 ml-5 text-white" style="background-color: indigo; max-width: 18rem;">
            <div class="card-header">Categories</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="view_all_categories.php" class="btn btn-primary p-2" style="float: right;">View Category</a>
                <?php echo $category["category"]; ?>
              </p>
            </div>
          </div>
        </div>
        <div class="row">

        <div class="card mb-3 ml-5 text-white" style="background-color: brown; max-width: 18rem;">
            <div class="card-header">Comments</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
              <a href="view_all_comments.php" class="btn btn-primary p-2" style="float: right;">View All Comments</a>
                <?php echo $comment["comment"]; ?>
              </p>
            </div>
          </div>

          <div class="card text-bg-dark mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">Posts</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="view_all_posts.php" class="btn btn-primary p-2" style="float: right;">View Posts</a>
                <?php echo $post_count["post_total"]; ?>
              </p>
            </div>
          </div>
        
          <div class="card text-bg-secondary mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">Blog Pages</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="view_all_pages.php" class="btn btn-primary p-2" style="float: right;">View Blog Pages</a><?php echo $blog["blog"]; ?>
              </p>
            </div>
          </div>

          <div class="card text-bg-dark mb-3 ml-5" style="max-width: 18rem;">
            <div class="card-header">Feedbacks</div>
            <div class="card-body">
              <h5 class="card-title">Total</h5>
              <p class="card-text">
                <a href="view_all_feedbacks.php" class="btn btn-primary p-2" style="float: right;">View Feedbacks</a>
                <?php echo $feedback["feedback"]; ?>
              </p>
            </div>
          </div>
        </div> 


    </div>
<?php
    DB_des_connection();
    require_once('footer.php');

?>		



