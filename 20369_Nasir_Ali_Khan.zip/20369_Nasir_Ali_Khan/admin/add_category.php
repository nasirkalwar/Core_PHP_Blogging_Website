<?php
    require_once("header.php");
    require_once("sidebar.php");
	
    
    if(isset($_GET["category_id"]))  {
 		
 		$cat_id = $_GET["category_id"];
	    $query  = "SELECT * FROM category WHERE category_id = $cat_id";
	    $result  = execute_query($query);
   		$row = mysqli_fetch_assoc($result);
    }
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
      <div id="content" class="p-4 p-md-5 pt-5">
      			<div class="row">
			    	<div class="col-md-2"></div>
			    		<div class="col-md-8 rounded text-white" style="background-color: darkseagreen;">
					<h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;"><?php echo isset($_GET["category_id"])?"Update Category":"Add Category" ?><a href="view_all_categories.php" class="btn btn-warning p-3" style="float: right;">View Category</a></h1>
					<?php 
					if(isset($_REQUEST["message"]))
						{
						?>
							<p style="background-color: <?php echo $_REQUEST["color"]; ?>; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
						<?php
						}
						?>
					<form action="process.php" method="POST">
						<div class="mb-3 mt-5">
						  <label for="exampleFormControlInput1" class="form-label">Category Name</label>
						  <input type="text" name="category_title" value="<?php echo isset($row["category_title"])?$row["category_title"]:""; ?>" class="form-control" id="exampleFormControlInput1" placeholder="Enter Category Name" required>
						  <div class="mb-3">
								<label for="exampleFormControlTextarea1" class="form-label">Category Description</label>
								<textarea class="form-control" name="category_description" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Category Description"><?php echo isset($row["category_description"])?$row["category_description"]:"" ?></textarea>
							</div>
						  <input type="hidden" name="user_id" value="<?php echo isset($_SESSION["user"]["user_id"])?$_SESSION["user"]["user_id"]:""; ?>">
						  <input type="hidden" name="category_id" value="<?php echo isset($row["category_id"])?$row["category_id"]:""?>" required>
						</div>
						  <select class="form-select" aria-label="Default select example" name="category_status">
		                    <option selected align="center" value="<?php echo isset($row["category_status"])?$row["category_status"]:""; ?>"><?php echo isset($row["category_status"])?$row["category_status"]:"--- Select Category Status ---"; ?></option>
		                    <option value="Active">Active</option>
		                    <option value="InActive">InActive</option>
		                  </select>
						<div class="col-12 mt-2">
						    <button class="btn btn-primary" type="submit" name="action" value="<?php echo  isset($row["category_id"])?"update_category":"add_category" ?>"><?php echo isset($row["category_id"])?"Update":"Add" ?></button>
		  				</div>
						
					</form>
				 </div>
			    <div class="col-md-2"></div>
			</div>
		</div>
	</div>

<?php    
    DB_des_connection();
	require_once("footer.php");

 ?>	    
