		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
        	<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
        <h1>
          <a href="dashborad.php" class="logo" style="background-color: darkseagreen;">
                <img src="../user/<?= $_SESSION['user']["user_image"]; ?>" class="img-fluid rounded-circle" style="height: 50px;  margin-left: 55px;" alt="image"><hr style="background-color:white;" />
             <span style="font-size: 18px;">
              Welcome :       <?= $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];?>
        
            </span>
          </a>
        </h1>        
        <ul class="list-unstyled components mb-5">
          <li class="">
            <a href="dashborad.php"><span class="fa fa-home mr-3"></span> Dashboard</a>
          </li>
          <li>
              <a href="user_request.php"><span class="fa fa-user mr-3"></span>User Request</a>
          </li>
          <li>
              <a href="add_blog_page.php"><span class="fa fa-sticky-note mr-3"></span> Add blog Page</a>
          </li>
          <li>
            <a href="add_category.php"><span class="fa fa-sticky-note mr-3"></span> Add Category</a>
          </li>
          <li>
            <a href="add_post.php"><span class="fa fa-sticky-note mr-3"></span> Add Post</a>
          </li>
          <li>
            <a href="add_users.php"><span class="fa fa-user mr-3"></span> Add User</a>
          </li>
          <li>
            <a href="view_all_pages.php"><span class="fa fa-sticky-note mr-3"></span> Manage Blog Pages</a>
          </li>
          <li>
            <a href="view_all_categories.php"><span class="fa fa-paper-plane mr-3"></span> Manage Categories</a>
          </li>
          <li>
            <a href="view_all_posts.php"><span class="fa fa-sticky-note mr-3"></span> Manage Posts</a>
          </li>
          <li>
            <a href="view_all_users.php"><span class="fa fa-user mr-3"></span> Manage Users</a>
          </li>
          <li>
            <a href="view_all_comments.php"><span class="fa fa-comment mr-3"></span> Manage Comments</a>
          </li>
          <li>
            <a href="view_all_feedbacks.php"><span class="fa fa-sticky-note mr-3"></span> View Feedbacks</a>
          </li>
          <li>
            <a href="logout.php"><span class="fa fa-sign-out mr-3"></span> Logout</a>
          </li>
        </ul>

    	</nav>
