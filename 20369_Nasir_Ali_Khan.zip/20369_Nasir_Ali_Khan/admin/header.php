<?php
    mysqli_report(false);
    require_once("../require/session.php");
    require_once("../require/database.php");
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>--- Admin Dashoboard---</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
    <!-- Bootstrap CSS File Link-->
    <link href="../bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Datatable File Link-->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

    <!-- Bootstrap Sidebar File Link-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">

  </head>
  <style>
    #sidebar ul li a:hover{
      background-color:darkseagreen ;
    }
  </style>
  <body>
