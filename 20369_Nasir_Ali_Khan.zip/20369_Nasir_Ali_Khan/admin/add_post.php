<?php
    require_once('header.php');
    require_once('sidebar.php');
    
    //Fetch Admin Blog Pages
    $user_id    = $_SESSION["user"]["user_id"];
    $query      = "SELECT * FROM blog WHERE user_id= $user_id";
    $result     = execute_query($query);

    //Fetch Categories
    $query_cat      = "SELECT * FROM category WHERE category_status='Active'";
    $result_cat     = execute_query($query_cat);


    //Update Post
    if(isset($_GET["post_id"]))  {

      $post_id = $_GET["post_id"];
      $que    = "SELECT * FROM post INNER JOIN blog ON post.blog_id = blog.blog_id WHERE post_id = $post_id";

      $res    = execute_query($que);
      $row1   = mysqli_fetch_assoc($res);

    $query_up_cat      = "SELECT * FROM category,post,post_category WHERE post.'$post_id'=post_category.'$post_id' AND post_category.category_id=category.category_id AND category_status='Active'";
    $result_up_cat     = execute_query($query_cat);

    }
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>

     <div id="content" class="p-4 p-md-5 pt-5">
          <div class="row">
            <div class="col-md-2"></div>
              <div class="col-md-8 rounded text-white" style="background-color: darkseagreen; height: auto;">

                  <h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;"><?php echo isset($_GET["post_id"])?"Update Post":"Add Post" ?><a href="view_all_posts.php" class="btn btn-warning p-3" style="float: right;">View Posts</a></h1>
                    <?php 
                  if(isset($_REQUEST["message"]))
                    {
                    ?>
                      <p style="background-color: <?php echo $_REQUEST["color"]; ?>; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
                    <?php
                    }
                    ?>

                    <form action="process.php" method="POST" enctype="multipart/form-data">
                      
                      <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Post Title</label>
                        <input type="text" name="post_title" value="<?php echo isset($row1["post_title"])?$row1["post_title"]:""; ?>" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Last Name" required>
                      </div>
                      <select class="form-select" aria-label="Default select example" name="blog_id" required>
                        <option selected align="center" value="<?php echo isset($row1["blog_id"])?$row1["blog_id"]:""; ?>"><?php echo isset($row1["blog_title"])?$row1["blog_title"]:"Select Blog Page" ?></option>
                        <?php
                          if($result->num_rows)
                          {
                            while($row = mysqli_fetch_assoc($result))
                            {
                        ?>
                            <option value="<?php echo $row["blog_id"]; ?>"><?php echo $row["blog_title"]; ?></option>
                          <?php
                            }
                        }else{
                        ?>
                            <option>No Page Found</option>
                        <?php
                        }
                        ?>          
                      </select>
                      <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Post Summary</label>
                        <textarea class="form-control" name="post_summary" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Address" required><?php echo isset($row1["post_summary"])?$row1["post_summary"]:""; ?></textarea>
                      </div>
                      <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Post Description</label>
                        <textarea class="form-control" name="post_description" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Address" required><?php echo isset($row1["post_description"])?$row1["post_description"]:""; ?></textarea>
                      </div>

                      <select multiple class="form-select" aria-label="Default select example" name="category_id[]" required>
                        <option selected align="center" value="<?php echo isset($row1["category_id"])?$row1["blog_id"]:""; ?>"><?php echo isset($row1["category_title"])?$row1["category_title"]:"Select Category" ?></option>
                        <?php
                          if($result->num_rows)
                          {
                            while($cate = mysqli_fetch_assoc($result_cat))
                            {
                            ?>
                            <option value="<?php echo isset($cate["category_id"])?$cate["category_id"]:""; ?>"><?php echo isset($cate["category_title"])?$cate["category_title"]:""; ?></option>
                          <?php
                          if ($_GET['post_id']) {
                            while($up_cate = mysqli_fetch_assoc($result_up_cat))
                            {
                            ?>
                            <option selected value="<?php echo isset($up_cate["category_id"])?$up_cate["category_id"]:""; ?>"><?php echo isset($up_cate["category_title"])?$up_cate["category_title"]:""; ?></option>
                          <?php
                            }
                          }
                        }
                        }else{
                        ?>
                            <option>No Page Found</option>
                        <?php
                        }
                        ?>          
                      </select multiple>

                      <div class="mb-3">
                        <label for="formFile" class="form-label">Featured Image</label>
                        <input class="form-control" type="file" name="featured_image" value="<?php echo isset($row1["featured_image"])?$row1["featured_image"]:""; ?>" id="formFile">
                        <input class="form-control" type="hidden" name="post_id" value="<?php echo isset($row1["post_id"])?$row1["post_id"]:""; ?>" id="formFile">

                      </div>
                      <select class="form-select" aria-label="Default select example" name="is_comment_allow">
                        <option selected align="center"  value="<?php echo isset($row1["is_comment_allowed"])?$row1["is_comment_allowed"]:""; ?>"><?php echo isset($row1["is_comment_allowed"])?$row1["is_comment_allowed"]:"Select Comment Is Allow"; ?></option>
                            <option value="Active">Active</option>
                            <option value="InActive">InActive</option>
                      </select>

                        <div class="col-md-12">
                          <div class="mb-3">
                            <label for="formFile" class="form-label">Enter Attachment Value</label>
                            <input class="form-control" type="text" name="count" id="count1" onblur="attachment(this)" >
                          </div>                          
                        </div> 
                        <div id="attachment">                          
                        </div>                     

                      <div class="col-12 mt-2">
                          <button class="btn btn-primary" type="submit" name="action" value="<?php echo  isset($row1["post_id"])?"update_post":"add_post" ?>"><?php echo isset($row1["post_id"])?"Update":"Add" ?></button>
                        </div>
                      
                    </form>
                  </div>
            <div class="col-md-2"></div>

    </div>
      <script type="text/javascript">
       function attachment(obj){

          var ajax_request = null;
          var count = count1.value;
      // console.log(count);

          if(window.XMLHttpRequest)
          {
            ajax_request = new XMLHttpRequest();
          }
          else
          {
            ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
          }

          ajax_request.onreadystatechange = function(){
            if(ajax_request.readyState == 4 && ajax_request.status == 200 && ajax_request.statusText == "OK")
            {
              document.getElementById("attachment").innerHTML = ajax_request.responseText;
            } 
          }

          ajax_request.open("GET","process.php?action=attachment&count="+count);
          ajax_request.send();
        }
      </script>
<?php
    
    DB_des_connection();
    require_once('footer.php');

?>

  