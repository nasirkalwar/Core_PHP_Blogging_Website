<?php

    require_once('header.php');
    require_once('sidebar.php');
        

    if(isset($_GET["blog_id"]))  {
 		
 		$blog_id = $_GET["blog_id"];
	    $query  = "SELECT * FROM blog WHERE blog_id = $blog_id";
	    $result  = execute_query($query);
   		$row = mysqli_fetch_assoc($result);
    }
    if (!isset($_SESSION["user"]) || $_SESSION["user"]["role_id"] !="1") {
        header("location: logout.php?");
      
    }
?>
    	<div id="content" class="p-4 p-md-5 pt-5">
    		    <div class="row">
			    	<div class="col-md-2"></div>
				    	<div class="col-md-8 rounded text-white" style="background-color: darkseagreen;">
			  				<h1 class="text-white text-center p-1 rounded" style="background-color: darkseagreen;"><?php echo isset($_GET["category_id"])?"Update Blog Page":"Add Blog Page" ?><a href="view_all_pages.php" class="btn btn-warning p-3" style="float: right;">View Blog Pages</a></h1>
					<?php 
					if(isset($_REQUEST["message"]))
						{
						?>
							<p style="background-color: <?php echo $_REQUEST["color"]; ?>; font-weight: bolder; border-radius: 5px;" align="center"><?php echo $_GET["message"]; ?></p>
						<?php
						}
						?>
							<form action="process.php" method="POST" enctype="multipart/form-data">
								<div class="mb-3 mt-5">
								  <label for="exampleFormControlInput1" class="form-label">Blog Page Title</label>
								  <input type="text" name="blog_title" value="<?php echo isset($row["blog_title"])?$row["blog_title"]:""; ?>" class="form-control" id="exampleFormControlInput1" placeholder="Enter Blog Page Name" required>
								</div>
								<div class="mb-3">
								  <label for="exampleFormControlInput1" class="form-label">Post Per Page</label>
								  <input type="number" name="post_per_page" value="<?php echo isset($row["post_per_page"])?$row["post_per_page"]:""; ?>" class="form-control" id="exampleFormControlInput1" placeholder="Enter Blog Page Name" required>
								</div>
								<div class="mb-3">
								  <label for="formFile" class="form-label">Blog Background Image</label>
								  <input class="form-control" name="blog_image" value="<?php echo isset($row["blog_background_image"])?$row["blog_background_image"]:""; ?>" type="file" id="formFile" required>
								</div>

								  <select class="form-select" aria-label="Default select example" name="blog_status" required>
				                    <option selected align="center" value="<?php echo isset($row["blog_status"])?$row["blog_status"]:""; ?>"><?php echo isset($row["blog_status"])?$row["blog_status"]:"--- Select Blog Page Status ---"; ?></option>
				                    <option value="Active">Active</option>
				                    <option value="InActive">InActive</option>
				                  </select>

								<input type="hidden" name="user_id" value="<?php echo isset($_SESSION["user"]["user_id"])?$_SESSION["user"]["user_id"]:""; ?>" required>
						  		<input type="hidden" name="blog_id" value="<?php echo isset($row["blog_id"])?$row["blog_id"]:""?>">	<div class="col-12">
								  <button class="btn btn-primary" type="submit" name="action" value="<?php echo  isset($row["blog_id"])?"update_blog":"add_blog" ?>"><?php echo isset($row["blog_id"])?"Update":"Add" ?></button>
				  			</form>
			    		</div>
			    	<div class="col-md-2"></div>
				</div>
			</div>
    	</div>
<?php
    DB_des_connection();
    require_once('footer.php');
?>

